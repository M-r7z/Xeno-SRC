#pragma once

void setup_connection();